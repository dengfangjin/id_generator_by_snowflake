================
Python SnowFlake
================

A library that provides snowflake features to python, including Client and Server. 
You will not need to

This is extend of https://github.com/koblas/pysnowflake with Client adding.


See `documentations <http://pysnowflake.readthedocs.org/en/latest/>`_

----------
Change log
----------

0.1.3
*****

* Fix syntax errors with python 2.7